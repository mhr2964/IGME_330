module.exports = {
    mode: 'development',
    entry: ['./src/loader.js'],
    output: {
        filename: './bundle.js'
    }
};